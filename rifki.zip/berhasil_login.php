<?php 
 
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}
 
?>
 
 <!DOCTYPE html>
<html>
<head>
	<title>Valleryo</title>
	<link rel="stylesheet" type="text/css" href="rv2.css">
</head>
<body>
<nav id="navbar">
	<a href="#welcome-section">HOME</a>
	<a href="#main">PRODUCT</a>
	<a href="#footer">CONTACT</a>
	<a href="#Logout">LOGOUT </a>
</nav>
<header id="welcome-section">
	<h1>Hello, </h1>
	<p>Selamat Datang Diwebsite Produk Digital</p>
</header>
<main id="main">
	<section id="projects">
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/spotify.jpg"></a>
			<div>Spotify Premium</div>
		</div>
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/ytbpremium.jpg"></a>
			<div>Youtube Premium</div>
		</div>
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/canvapro.jpg"></a>
			<div>Canva Pro</div>
		</div>
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/rifkiii.jpg"></a>
			<div></div>
		</div>
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/neflix.jpg"></a>
			<div>Neflix</div>
		</div>
		<div class="project-tile">
		<a href="#" target="_blank"><img src="img/rifqi.jpg"></a>
			<div> </div>
		</div>
	</section>
	<button><a href="https://api.whatsapp.com/send?phone=6285807448886&text=Hallo%20Saya%20Ingin%20Memesan%20Akun%20Tersebut" target="_blank">Untuk Melakukan Pembelian , Klik Disni.</a></button>
</main>
<footer id="footer">
	<div>
		<a id="profile-link" href="https://www.facebook.com/MasRif.123098" target="_blank"><img src="img/rifkiii.jpg" width="150px"></a>
		<p>Facebook profile</p>
	</div>

	<div>
		<a id="#" href="#" target="#"><img src="img/rifkiii.jpg" width="150px"></a>
		<p>Amann</p>
	</div>
	<div>
		<a href="https://www.instagram.com/yxcxxvb/" target="_blank"><img src="img/rifkiii.jpg" width="150px"></a>
		<p>Letgo</p>
    </div>
</footer>


<footer id="Logout">
    <title>Berhasil Login</title>
</head>
<body>
    <div class="container-logout">
        <form action="" method="POST" class="login-email">
            <?php echo "<h1>Selamat Datang, " . $_SESSION['username'] ."!". "</h1>"; ?>
            <div class="input-group">
            <a href="logout.php" class="btn" img src="img/rifkiii.jpg">Logout</a>
            </div>
        </form>
    </div>
</body>
</html>